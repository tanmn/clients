SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


DROP TABLE IF EXISTS `hotline_requests`;
CREATE TABLE IF NOT EXISTS `hotline_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotline` varchar(15) NOT NULL,
  `number` varchar(15) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=549836 ;
DROP VIEW IF EXISTS `invalid_points`;
CREATE TABLE IF NOT EXISTS `invalid_points` (
`hotline` varchar(15)
,`report_date` date
,`number` varchar(15)
,`points` decimal(33,0)
);
DROP TABLE IF EXISTS `master_groups`;
CREATE TABLE IF NOT EXISTS `master_groups` (
  `group_code` varchar(55) NOT NULL,
  `hotline` varchar(15) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `winner_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`group_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `master_hotlines`;
CREATE TABLE IF NOT EXISTS `master_hotlines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotline` varchar(15) NOT NULL,
  `active_flag` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

DROP TABLE IF EXISTS `master_points`;
CREATE TABLE IF NOT EXISTS `master_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `report_date` date NOT NULL,
  `hotline` varchar(15) NOT NULL,
  `msg_type` varchar(15) NOT NULL,
  `group_code` varchar(55) NOT NULL,
  `number` varchar(15) NOT NULL,
  `quantity` int(11) NOT NULL,
  `virtual_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=354940 ;

DROP TABLE IF EXISTS `master_users`;
CREATE TABLE IF NOT EXISTS `master_users` (
  `number` varchar(15) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `real_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `device` varchar(100) NOT NULL,
  `avatar` mediumblob,
  `winner_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
DROP VIEW IF EXISTS `request_count_by_date`;
CREATE TABLE IF NOT EXISTS `request_count_by_date` (
`hotline` varchar(15)
,`report_date` date
,`request_count` bigint(21)
,`number_count` bigint(21)
);DROP VIEW IF EXISTS `request_report`;
CREATE TABLE IF NOT EXISTS `request_report` (
`number` varchar(15)
,`hotline` varchar(15)
,`request_count` bigint(21)
,`latest_request_date` datetime
);
DROP TABLE IF EXISTS `user_qrcodes`;
CREATE TABLE IF NOT EXISTS `user_qrcodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telephone` varchar(255) DEFAULT NULL,
  `Point` varchar(255) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=136 ;
DROP TABLE IF EXISTS `invalid_points`;

CREATE ALGORITHM=UNDEFINED DEFINER=`faceinter_viber`@`localhost` SQL SECURITY DEFINER VIEW `invalid_points` AS select `master_points`.`hotline` AS `hotline`,`master_points`.`report_date` AS `report_date`,`master_points`.`number` AS `number`,sum(if((`master_points`.`msg_type` = 'sticker'),(`master_points`.`quantity` * 3),(`master_points`.`quantity` * 1))) AS `points` from `master_points` where ((`master_points`.`number` = `master_points`.`group_code`) and (`master_points`.`virtual_flag` = 0)) group by `master_points`.`hotline`,`master_points`.`report_date`,`master_points`.`number` order by `master_points`.`hotline`,`master_points`.`report_date` desc,sum(if((`master_points`.`msg_type` = 'sticker'),(`master_points`.`quantity` * 3),(`master_points`.`quantity` * 1))) desc limit 1000;
DROP TABLE IF EXISTS `request_count_by_date`;

CREATE ALGORITHM=UNDEFINED DEFINER=`faceinter_viber`@`localhost` SQL SECURITY DEFINER VIEW `request_count_by_date` AS select `hotline_requests`.`hotline` AS `hotline`,cast(`hotline_requests`.`created` as date) AS `report_date`,count(`hotline_requests`.`number`) AS `request_count`,count(distinct `hotline_requests`.`number`) AS `number_count` from `hotline_requests` where (cast(`hotline_requests`.`created` as date) < now()) group by `hotline_requests`.`hotline`,cast(`hotline_requests`.`created` as date) order by cast(`hotline_requests`.`created` as date) desc;
DROP TABLE IF EXISTS `request_report`;

CREATE ALGORITHM=UNDEFINED DEFINER=`faceinter_viber`@`localhost` SQL SECURITY DEFINER VIEW `request_report` AS select `hotline_requests`.`number` AS `number`,`hotline_requests`.`hotline` AS `hotline`,count(`hotline_requests`.`id`) AS `request_count`,`hotline_requests`.`created` AS `latest_request_date` from `hotline_requests` where (`hotline_requests`.`created` < now()) group by `hotline_requests`.`number`,`hotline_requests`.`hotline` order by `hotline_requests`.`created` desc;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
